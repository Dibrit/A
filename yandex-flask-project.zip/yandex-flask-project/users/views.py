from flask import jsonify, request

from flask.blueprints import Blueprint

from database import db
from users.models import User
from utils import validate_required_fields, validate_item_exists

blueprint = Blueprint(
    'users', __name__,
    template_folder='templates',
    static_folder='static'
)


@blueprint.route('/', methods=['POST'])
def create_user():
    error, message = validate_required_fields('username', 'password')
    if error:
        return message
    else:
        user = User(
            username=request.json['username'],
            first_name=request.json.get('first_name'),
            last_name=request.json.get('last_name'),
            role=request.json.get('role'),
        )
        user.set_password(request.json['password'])
        db.session.add(user)
        db.session.commit()
        return jsonify(
            user.to_dict()
        )
