import requests

HOST = '127.0.0.1'
PORT = 5000
BASE_URL = f'http://{HOST}:{PORT}/api'


def add_user(first_name, role):
    response = requests.post(f'{BASE_URL}/users', json={
        'username': 'admin',
        'password': 'admin',
        'first_name': first_name,
        'last_name': 'Несветайлов',
        'role': role
    })
    print(response.json())


def add_course():
    response = requests.post(f'{BASE_URL}/courses', json={
        'title': 'Основы промышленного программирования | Д20'
    })
    print(response.json())


def add_lesson():
    response = requests.post(f'{BASE_URL}/courses/1', json={
        'title': 'Итоговая самостоятельная работа',
        'description': """В самостоятельной работе вы можете получить неполный балл за задачу, если ваше решение 
        пройдёт только часть тестов. После выставления неполного балла вы также можете отправлять решения. """,
    })
    print(response.json())


def add_student_to_course(student_id):
    response = requests.post(f'{BASE_URL}/courses/1/students', json={
        'student_id': student_id
    })
    print(response.json())


add_user(first_name='Alik', role='Teacher')
add_user(first_name='Artem', role='Student')
add_user(first_name='Timur', role='Student')
add_course()
add_course()
add_lesson()
add_lesson()
add_lesson()
add_lesson()
add_student_to_course(2)
add_student_to_course(3)
