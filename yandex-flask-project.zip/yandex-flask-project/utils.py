from flask import request, jsonify


def validate_not_empty():
    if not request.json:
        return 1, jsonify({'error': 'Empty request'})
    else:
        return 0, {}


def validate_required_fields(*args):
    error, message = validate_not_empty()
    if error:
        return message
    else:
        if not all(key in request.json for key in args):
            return 1, jsonify({'error': 'Bad request'})
        else:
            return 0, {}


def validate_item_exists(Model, item_id):
    item = Model.query.get(item_id)
    if not item:
        return 1, jsonify({'error': 'Not found'})
    else:
        return 0, item
