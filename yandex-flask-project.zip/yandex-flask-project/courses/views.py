from flask import jsonify, request

from courses.models import Course, Lesson, users_to_courses
from flask.blueprints import Blueprint

from database import db
from utils import validate_not_empty, validate_required_fields, validate_item_exists

blueprint = Blueprint(
    'courses', __name__,
    template_folder='templates',
    static_folder='static'
)


@blueprint.route('/', methods=['GET'])
def list_course():
    query = Course.query.all()
    return jsonify(
        [
            item.to_dict(
                only=(
                    'id',
                    'created_date',
                    'teacher.id',
                    'teacher.first_name',
                    'teacher.last_name',
                    'title',
                    'students.first_name',
                    'students.last_name',
                    'students.id'
                )
            ) for item in query
        ]
    )


@blueprint.route('/<int:course_id>', methods=['GET'])
def get_course(course_id):
    error, item = validate_item_exists(Course, course_id)
    if error:
        return item
    else:
        return jsonify(
            item.to_dict(only=(
                'id',
                'created_date',
                'teacher.id',
                'teacher.first_name',
                'teacher.last_name',
                'title',
                'students.first_name',
                'students.last_name',
                'students.id'
            ))
        )


@blueprint.route('/', methods=['POST'])
def create_course():
    error, message = validate_required_fields('title')
    if error:
        return message
    else:
        course = Course(
            title=request.json['title']
        )
        db.session.add(course)
        db.session.commit()
        return jsonify(
            course.to_dict()
        )


@blueprint.route('/<int:course_id>', methods=['POST'])
def create_lesson(course_id):
    lesson = Lesson(
        title=request.json['title'],
        description=request.json['description'],
        course_id=course_id
    )
    db.session.add(lesson)
    db.session.commit()
    return jsonify(
        lesson.to_dict()
    )


@blueprint.route('/<int:course_id>/lessons', methods=['GET'])
def list_lesson(course_id):
    query = Lesson.query.filter_by(course_id=course_id)
    return jsonify(
        [
            item.to_dict(
                only=(
                    'id',
                    'title',
                    'description',
                    'is_published',
                    'created_date',
                    'course_id'
                )
            ) for item in query
        ]
    )


@blueprint.route('/<int:course_id>/students', methods=['POST'])
def add_student(course_id):
    error, item = validate_item_exists(Course, course_id)
    if error:
        return item
    else:
        error, message = validate_required_fields('student_id')
        if error:
            return message
        else:
            student_id = request.json['student_id']
            from users.models import User
            error, student = validate_item_exists(User, student_id)
            if error:
                return student
            else:
                print('Role', student.role)
                if student.role != 'Student':
                    return jsonify(
                        {
                            'error': 'User is not student'
                        }
                    )
                statement = users_to_courses.insert().values(
                    user_id=student.id,
                    course_id=item.id
                )
                db.session.execute(statement)
                db.session.commit()
                return jsonify(
                    item.to_dict(only=(
                        'id',
                        'created_date',
                        'teacher.id',
                        'teacher.first_name',
                        'teacher.last_name',
                        'title',
                        'students.first_name',
                        'students.last_name',
                        'students.id'
                    ))
                )
