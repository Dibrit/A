import datetime

from sqlalchemy import orm
from sqlalchemy_serializer import SerializerMixin

from database import db
from users.models import User

users_to_courses = db.Table(
    'users_to_courses',
    db.Column('user_id', db.Integer, db.ForeignKey('users.id'), primary_key=True),
    db.Column('course_id', db.Integer, db.ForeignKey('courses.id'), primary_key=True)
)


class Course(db.Model, SerializerMixin):
    __tablename__ = 'courses'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String, nullable=True)
    created_date = db.Column(db.DateTime, default=datetime.datetime.now)
    is_published = db.Column(db.Boolean, default=True)
    teacher_id = db.Column(db.Integer, db.ForeignKey('users.id'), default=1)
    teacher = orm.relation(User)
    students = db.relationship(
        User,
        secondary=users_to_courses,
        backref=db.backref(
            'courses',
            uselist=False
        )
    )


class Lesson(db.Model, SerializerMixin):
    __tablename__ = 'lessons'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String, nullable=True)
    created_date = db.Column(db.DateTime, default=datetime.datetime.now)
    is_published = db.Column(db.Boolean, default=True)
    description = db.Column(db.String, nullable=True)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'))
    course = orm.relation(Course)
