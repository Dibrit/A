import os

from flask import Flask

import courses
import users
from database import db


def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///courses_db.sqlite'
    db.init_app(app)
    app.register_blueprint(courses.blueprint, url_prefix='/api/courses')
    app.register_blueprint(users.blueprint, url_prefix='/api/users')
    return app


def setup_database(app):
    with app.app_context():
        db.create_all()


def main():
    app = create_app()
    # if not os.path.isfile('courses_db.sqlite'):
    setup_database(app)
    app.run()


if __name__ == '__main__':
    main()
